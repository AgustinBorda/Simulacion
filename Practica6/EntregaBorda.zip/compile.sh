gcc -o RandomNumberGenerator rng.c -lm
