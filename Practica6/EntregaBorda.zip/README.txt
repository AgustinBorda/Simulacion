Para compilar ejecutar el script: compile.sh

Para ejecutar el programa y graficar los puntos utilizar el script: run.sh

Para correr run.sh se le deben pasar los argumentos de la siguiente forma:
./run.sh x0 a c m
siendo x0 la seed inicial de nuestro programa (ejemplo dado en evelia 1234567),
a es el factor de multiplicacion (ejemplo de evelia 16807),
c es el factor de incremento lineal (ejemplo de evelia 0) y
m es el modulo de la expresion (ejemplo de evelia 2147483647).

Si al ejecutar alguno de los scripts nos dice que no tenemos permiso,
utilizar el comando chmod 777 <nombre del script>.

Respecto a vver si los puntos estan dispersos en el grafico o si dejan vacios,
parecen estar bastante bien distribuidps.

