El codigo fuente se ubica en la carpeta src.
Para compilarlo utilizar el script compile.sh de la carpeta scripts,
si el SO no le da permiso, ejecute el comando chmod 777 compile.sh.
Para correr el programa, utilizar el script run.sh (si no tiene permiso usar chmod 777 run.sh).

La forma de utilizar el script run.sh es:
	./run.sh <velocidadInicial> <velocidadFinal> <ba> <m> <g> <k> <b> <tiempoInicio> <tiempoFin> <h>

Si se quiere correr el programa con los valores dados en la practica, utilizar runWintGivenValues.sh
(si el SO no da permiso, utilizar chmod 777 runWintGivenValues.sh).

Los valores generados estan en output/output.txt.
La primera columna es el tiempo, la segunda la altura y la tercera la velocidad.
