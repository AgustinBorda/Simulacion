#Compile the libraries
gcc AleatoryNumber.h;
gcc Structures.h;
gcc Queue.h;
#Compile the simulator
gcc -o Simulator mm1-estructura.c
