typedef struct Cliente{
  int timeArrived;
}Cliente;
