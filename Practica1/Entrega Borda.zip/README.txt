Autor: Borda Agustin

Para compilar desde Linux correr el .sh compile,
si bash le deniega el permiso utilizar el comando "chmod 777 compile".
Para ejecutar escriba en la terminal ./Simulator.

Para compilar desde windows ejecute el archivo compile.bat.
Para ejecutar, haga doble click en el ejecutable Simulator.

Si desea cambiar el tiempo de la simulacion, escriba el tiempo que desee en el archivo "config.txt",
recuerde que es un float.

En respuesta al ejercicio, si sera necesaria otra lavadora, ya que en la mayoria de las simulaciones ejecutadas, se tiene un grado de utilizacion del 75 al 97 por ciento,
el cual es excesivamente alto.
